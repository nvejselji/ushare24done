# -*- coding: utf-8 -*-
import os
from os import listdir
import re # for regular expressions
import datetime

""" Functions for processing the text from the files, the text from the forms and the text from the cookies """

# --------------------- Materials ------------------------- #


def list_sel_mat(mat, y):
    directory = 'materiale/materiale.txt'
    path = os.path.abspath(directory)
    path = path.replace("\\", "/")
    
    mode='r+'
    file_t = open(path, mode)
    list_f = file_t.readlines()
    file_t.close()

    name = []
    link = []


    if len(list_f)>0:
        for line in list_f:
            li = line.split()
            n = li[0:-3] # name of the material
             # link
            if li[-2] == mat and li[-1] ==y:
                link.append(li[-3])
                name.append(' '.join(n))
    else:
        name = ""
        link = ""
    
    if len(list_f)>0:    
        name.reverse() # lastest added first in the page
        link.reverse()
    
    return (name, link)
    



def list_mat():
    directory = 'materiale/materiale.txt'
    path = os.path.abspath(directory)
    path = path.replace("\\", "/")
    
    mode='r+'
    file_t = open(path, mode)
    list_f = file_t.readlines()
    file_t.close()

    name = []
    link = []
    classes = []
    year = []

    if len(list_f)>0:
        for line in list_f:
            li = line.split()
            n = li[0:-3] # name of the material
            link.append(li[-3]) # link
            classes.append(li[-2])
            year.append(li[-1])
            
            name.append(' '.join(n))
    else:
        name = ""
        link = ""
        classes = ""
        year = ""
    
    if len(list_f)>0:    
        name.reverse() # lastest added first in the page
        link.reverse()
        classes.reverse()
        year.reverse()
    
    return (name, link)
    


def add_mat(title_mat, upload_file, classes, year_mat):
    mode = 'a' # Open for writing.  The file is created if it does not exist.
    #The stream is positioned at the end of the file.
         
    
    path = os.path.abspath('materiale/materiale.txt')
    path = path.replace("\\", "/")
    fob = open(path, mode)
    
    fob.write(title_mat + " " + str(upload_file) + " " + classes + " " + year_mat + '\n')
    
    fob.close()

        




# --------------------- Loggs ------------------------- #


def pass_validation(password):
    """ Password strength validation """
    """ The password has to contain at least 8 characters {8, } """
    """ The password must contain at least une digit, one special character, one lowercase and one uppercase"""
        
    if re.match(r'^(?=.*?\d)(?=.*?[A-Z])(?=.*?[a-z])(?=.*?\W)[A-Za-z\d\W]{8,}$', password):
        return True
    else:
        return False

    
def email_validation(email):
    """ Email validation """
    """ The email has to contain at least one [at] symbol subsequently followed by a dot """
    
    if re.match(r'[^@]+@[^@]+\.[^@]+', email):
        return True
    else:
        return False


def email_exist(email):
    """ Checks whether the email exists in the accounts db """
    
    mode = 'r'
    path = os.path.abspath('date/accounts.txt')
    path = path.replace("\\", "/")
    fob = open(path, mode)
    all_text = fob.read()
    fob.close()
    if email in all_text:
        return True
    else:
        return False

def f_validation(sname, name, email, password, password2):
    """ Form validation """
    """ The form has to be completed, the email valid and the password strong """    
    
    not_comp = ''
    if len(sname) == 0:
        not_comp = not_comp + 'Glömt ditt förnamn<br/>'
    if len(name) == 0:
        not_comp = not_comp + 'Glömt ditt efternamn</br>'
    if len(email) == 0:
        not_comp = not_comp + 'Glömt din E-postadress</br>'
    if len(password) == 0:
        not_comp = not_comp + 'Glömt lösenord</br>'
    if len(password2) == 0:
        not_comp = not_comp + 'Ditt lösenord fyller inte kraven. Försök igen!</br>'
        
    if password != password2:
        not_comp = not_comp + 'Lösenord matchar inte</br>'
    
    p_v = pass_validation(password)        
    if not(p_v):
        not_comp = not_comp + 'Skriv ett nytt lösenord. Den är inte tillräckligt stark.</br>'
    
    e_v = email_validation(email)    
    if not(e_v):
        not_comp = not_comp + 'E-postadress är inte giltigt</br>'
    
    exists = email_exist(email)
    if exists:
        not_comp = not_comp + 'E-postadress finns redan</br>'
        
    
    return not_comp




def write_s(email, sid):
    """ Adds the email and the session id the the session db """
     
    mode = 'a' # Open for writing.  The file is created if it does not exist.
    #The stream is positioned at the end of the file.
         
    
    path = os.path.abspath('date/sessions.txt')
    path = path.replace("\\", "/")
    fob = open(path, mode)
    fob.write(email + " " + str(sid) + '\n')
    
    fob.close()


def get_email(sid):
    """ Using the session id stored in the cookie the function retrieves the user email """    
    
    mode = 'r+' # Opens a file for both reading and writing.
    #The file pointer placed at the beginning of the file.
    path = os.path.abspath('date/sessions.txt')
    path = path.replace("\\", "/")
    searchfile = open(path, mode)
    
    in_list = False
    searchfile.seek(0)    
    for line in searchfile:
        if sid in line:
            in_list = True
            li = line.split()
            searchfile.close()
            return li[0]
    if not(in_list):
        searchfile.close()
        return False
        


def delete_session(sid):
    """ When a user loggs out its session is deleted form the session db """    
    
    updated=''    
    mode = 'r+'
    path = os.path.abspath('date/sessions.txt')
    path = path.replace("\\", "/")
    searchfile = open(path, mode)

    for line in searchfile:
        if not(sid in line):
            updated = updated + line
    
    searchfile.close()
    searchfile = open(path, 'w')
    searchfile.writelines(updated)
    searchfile.close()



# --------------------- Discusssions ------------------------- #
   

def take_list_disc(name):
    directory = 'date/discutii/' + name
    path = os.path.abspath(directory)
    path = path.replace("\\", "/")
    files = listdir(path)
    files.remove('det.txt')
    
    files.sort(key=lambda x: os.stat(os.path.join(directory, x)).st_mtime, reverse = True)
    #Will sort the files list by the last modified time of the files 
    
    for i in range(len(files)):
        files[i] = str(files[i])[0:-4]
        
    # take name and store in a list
    usernames = []
    for i in range(len(files)):
        path_n = path + "/" + files[i] + ".txt"
        t = open(path_n, 'r')
        un = t.readline() # reads the first line, the one containing the username of the creator of the disc
        usernames.append("Diskussion påbörjat av <b>" + un + "</b>.")
    
    return (files, usernames)



def add_disc(name, title_disc, email):
    
    
    directory = 'date/discutii/' + name
    path = os.path.abspath(directory)
    path = path.replace("\\", "/")
    path = path + "/" + title_disc + ".txt"
    
    mode = 'a'
    new_di = open(path, mode)
    if email == 'ushare24':
        email = 'administrator'
    text_w = email + '\n'
    new_di.write(text_w)
    new_di.close()    
    
    return True



def take_list_comm(name, disc):
    directory = 'date/discutii/' + name
    path = os.path.abspath(directory)
    path = path.replace("\\", "/")
    path = path + "/" + disc + ".txt"
    mode='r+'
    file_t = open(path, mode)
    list_f = file_t.readlines()
    file_t.close()

    comm = []
    un = []
    date = []
    key = []
    
    list_f = list_f[1:]

    if len(list_f)>0:
        for line in list_f:
            li = line.split()
            key.append(li[0])# key
            un.append(li[1]) # username / email
            date.append(li[2]) #date
            l_c = li[3:] # comment
            comm.append(' '.join(l_c))
    else:
        comm=""
        un=""
    
    return (comm, un, date, key)




def add_comm(name, disc, comment, email):
    directory = 'date/discutii/' + name
    path = os.path.abspath(directory)
    path = path.replace("\\", "/")
    path = path + "/" + disc + ".txt"
    
    mode = 'a+'
    new_di = open(path, mode)
    comment = comment.replace('\n', '<br />')
    list_f = new_di.readlines()
    
    if len(list_f) == 1:
        key = '1'
    else:
        last_rec = list_f[-1]
        last_key = last_rec.split()[0]
        key = int(last_key) + 1
        key = str(key)
        
        
    
    now = datetime.datetime.now()
    date = str(now.hour) + ':' + str(now.minute) + '--' + str(now.day) +'/'+ str(now.month) +'/'+ str(now.year)
    if email == 'ushare24':
        email = 'administrator'
    
    
        
    text_w = key + " " + email + " " + date + " " + comment + "\n"
    new_di.write(text_w)
    new_di.close()


    return True



def delete_comm(name, disc, record):
    
    directory = 'date/discutii/' + name
    path = os.path.abspath(directory)
    path = path.replace("\\", "/")
    path = path + "/" + disc + ".txt"
    
    updated=''    
    mode = 'r+'
    searchfile = open(path, mode)

    for line in searchfile:
            li = line.split()
            if not li[0] == record:
                updated = updated + line
    
    searchfile.close()
    searchfile = open(path, 'w')
    searchfile.writelines(updated)
    searchfile.close()

    return True






