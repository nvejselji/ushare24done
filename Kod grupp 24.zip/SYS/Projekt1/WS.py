# coding: utf-8
# Author: Mirela Hilmkvist, Naxhie Vejselji

from bottle import route, run, template, request, static_file, error, response, get, post, url
import os

from text_p import *
from loggs import *
from admin import *



@error(404)
def error404(error):
    """
    Shows an error message whenever the user tries to acces a page that does not exist.
    """
    
    sid = request.get_cookie("account", secret='some-secret-key')
    email = get_email(str(sid))   
    if email:
        return template("template.tpl", base="</br><h2>Sidan uppdateras, kommer snart....</h2>", email=email, url=url)
    else:
        return template("template.tpl", base="</br><h2>Sidan uppdateras, kommer snart....</h2>", email='', url=url)
    
    

@route('/')
def start():
    """
    Shows the home page.
    """
    
    sid = request.get_cookie("account", secret='some-secret-key')
    email = get_email(str(sid))
    
    if email:
        return template("start.tpl", email=email, message='', url=url)
    else:
        return template("start.tpl", email='', message='', url=url)


# -------- Materiale ----------------------------------------

@route('/materials')
def materials():
    sid = request.get_cookie("account", secret='some-secret-key')
    email = get_email(str(sid))
    
    (name, link)  = list_mat()
    
    if email:
        return template("page_mat.tpl", name = name, link = link, email = email, url=url)
    else:
        return template("page_mat.tpl", name = name, link = link, email='', url=url)


@route('/recommend a material')
def mat():
    sid = request.get_cookie("account", secret='some-secret-key')
    email = get_email(str(sid))  
    
    if email:
        return template("materiale.tpl", email = email, url=url)
    else:
        return template("materiale.tpl", email='', url=url)




@route('/upload', method="POST")
def upload_mat():
    
    sid = request.get_cookie("account", secret='some-secret-key')
    email = get_email(str(sid))
    
 


    if email and '@' not in email:
    
            title_mat = request.forms.get('title_mat')
            year_mat = request.forms.get('year_mat')
            classes = request.forms.get('classes')
            upload = request.files.get('upload')
            
            name, ext = os.path.splitext(upload.filename)
            if ext not in ('.png', '.jpg', '.jpeg', '.pdf', '.mp4', 'mp3'):
                    return "File extension not allowed."    
            
            save_path =  os.path.abspath('materiale')
            file_path = "{path}/{file}".format(path=save_path, file=upload.filename)
            upload.save(file_path)    
            
            #str(name).replace(' ', '_')
            add_mat(title_mat, name + ext, classes, year_mat)
            
            (name, link)  = list_mat()
        
            return template("page_mat.tpl", name = name, link = link, email = email, url=url)
            
    else:
        

        title_mat = request.forms.get('title_mat')
        upload = request.files.get('upload')
        
        name, ext = os.path.splitext(upload.filename)
        if ext not in ('.png', '.jpg', '.jpeg', '.pdf', '.mp4', 'mp3'):
                return "File extension not allowed."    
        
        save_path =  os.path.abspath('materiale_recomandate')
        file_path = "{path}/{file}".format(path=save_path, file=upload.filename)
        upload.save(file_path)
        
        (name, link)  = list_mat()
        redirect('/materials')



#-----------------Program ----------------------------------------

@route('/program')
def programs():
    sid = request.get_cookie("account", secret='some-secret-key')
    email = get_email(str(sid))   
    if email:
        return template('program.tpl', email = email, url=url)
    else:
        return template('program.tpl', email='', url=url)


@route('/program/arhitect')
def arhitect():
    sid = request.get_cookie("account", secret='some-secret-key')
    email = get_email(str(sid))   
    if email:
        return template('arhitect.tpl', email=email, url=url)
    else:
        return template('arhitect.tpl', email='', url=url)


@route('/program/arhitect/year<y>')
def mat_y(y):   
    
    sid = request.get_cookie("account", secret='some-secret-key')
    email = get_email(str(sid))
    
    mat = 'IA'
    y = str(y)
    (name, link) = list_sel_mat(mat, y)
    
    if email:
        return template('mat_y.tpl', name = name, link = link, email=email, url=url)
    else:
        return template('mat_y.tpl', name = name, link = link, email='', url=url)



@route('/program/system')
def system():
    sid = request.get_cookie("account", secret='some-secret-key')
    email = get_email(str(sid))
    if email:
        return template('system.tpl', email=email, url=url)
    else:
        return template('system.tpl', email='', url=url)

@route('/program/spel')
def spel():
    sid = request.get_cookie("account", secret='some-secret-key')
    email = get_email(str(sid))
    if email:
        return template('spel.tpl', email=email, url=url)
    else:
        return template('spel.tpl', email='', url=url)

@route('/program/app')
def app():
    sid = request.get_cookie("account", secret='some-secret-key')
    email = get_email(str(sid))
    if email:
        return template('app.tpl', email=email, url=url)
    else:
        return template('app.tpl', email='', url=url)





@route('/contact')
def contact():
    sid = request.get_cookie("account", secret='some-secret-key')
    email = get_email(str(sid))   
    if email:
        return template('contact.tpl', email=email, url=url)
    else:
        return template('contact.tpl', email='', url=url)


"""The main job of the session table is used to translate between the session key and the user identity.
 The session table stores the username as part of the session data so that when a valid cookie is received,
 the application can identify the logged in user."""




#------------------ Need log in ------------------------------------------------------


@route('/conversations')
def conversations():
    
    """ Shows a list of discussuins cathegory """
    """ Only the administrator can add a new cathegory of discussions """
    
    #verify
    sid = request.get_cookie("account", secret='some-secret-key')
    email = get_email(str(sid))
    
    path = os.path.abspath('date/discutii')
    path = path.replace("\\", "/")
    files = listdir(path)
    mode='r'    
    
    text = []
    for fis in files:
        n_path = path + '/' + fis +'/det.txt'
        fob = open(n_path, mode)
        all_text = fob.read()
        text.append(all_text)
        fob.close()
    
    if email:
        return template("discussions", email = email, list_sf = files, detalii = text, url=url)
    else:
        redirect('/login')


@post('/conversations')
def add_sf():
    """ A new sub-forum by adding a directory with the name of the sub-forum and
    a text file containing the details of the sub-forum """    
    
    sid = request.get_cookie("account", secret='some-secret-key')
    email = get_email(str(sid))
    
    
    title_sf = request.forms.get('title_sf')
    det = request.forms.get('det')
    
    path = os.path.abspath('date/discutii')
    path = path.replace("\\", "/")
    
    if not os.path.exists(path + '/' + title_sf):
        path = path + '/' + title_sf
        os.mkdir(path)  # adds a new directory 
        mode = 'a'
        new_di = open(path + '/det.txt', mode) # adds a new txt file
        new_di.write(det)
        new_di.close() 
        
        

        
    path = os.path.abspath('date/discutii')
    path = path.replace("\\", "/")
    files = listdir(path)
    mode='r'    
    
    text = []
    for fis in files:
        n_path = path + '/' + fis +'/det.txt'
        fob = open(n_path, mode)
        all_text = fob.read()
        text.append(all_text)
        fob.close()
        
    return template("discussions", email = email, list_sf = files, detalii = text, url=url)
        
    
    


@get('/conversations-<name>')
def sub_forums(name):
    
    """ Shows a list of discussions from a selected cathegory """
    """ A logged user can start a discussion """
    
    sid = request.get_cookie("account", secret='some-secret-key')
    email = get_email(str(sid))
    # get all text files add possibility to add a discusion
    
    (files, un) = take_list_disc(name)

    if email:
        return template("sub_discussions", email = email, name = name, disc = files, un=un, msg = '', url=url)
    else:
        return template("login.tpl", matching="", email = '', url=url)


@post('/conversations-<name>')
def new_disc(name):

    sid = request.get_cookie("account", secret='some-secret-key')
    email = get_email(str(sid))
    
    title_disc = request.forms.get('title_disc')
    #if in directory message if not message added
    
    (files, un) = take_list_disc(name)
    
    if title_disc in files:
        msg = "Diskussionen finns redan."
    else:
        add_disc(name, title_disc, email)
        msg = "Diskussionen är redan aktiv."
    
    (files, un) = take_list_disc(name) # show the new list of discussions
    
    
    return template("sub_discussions", email = email, name = name, disc = files, un=un, msg = msg, url=url)
    










@get('/conversations-<name>/<disc>')
def disc(name, disc):
    
    """ Shows the comments of a specific discussion """ 
    
    sid = request.get_cookie("account", secret='some-secret-key')
    email = get_email(str(sid))
    
    (comments, un, date, key) = take_list_comm(name, disc)
    
    if email:
        return template("one_discussion", email = email, name=disc, bk = name, comments = comments, un = un, date = date, key=key, url=url)
    else:
        return template("login.tpl", matching="", email = '', url=url)



@post('/conversations-<name>/<disc>')
def new_comm(name, disc):
    
    sid = request.get_cookie("account", secret='some-secret-key')
    email = get_email(str(sid))
    
    if request.forms.get('btn') == 'Lägg till':
        comment =  request.forms.get('comm')
        add_comm(name, disc, comment, email)
    else:
        record = request.forms.get('rec')
        delete_comm(name, disc, record)
        
    
    (comments, un, date, key) = take_list_comm(name, disc)

    if email:
        return template("one_discussion", email = email, name=disc, bk = name, comments = comments, un = un, date = date, key=key, url=url)
    else:
        return template("login.tpl", matching="", email = '', url=url)







# for css files stored in the folder named static
@route('/static/<filepath:path>', name='static')
def server_static(filepath):
    return static_file(filepath, root='static')

# for pdf documents stored in the folder materiale
@route('/materiale/<filepath:path>', name='materiale')
def pdf_static(filepath):
    return static_file(filepath, root='materiale')


run(host='localhost', port= 9084, debug=True, reloader=True)











