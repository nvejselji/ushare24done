# -*- coding: utf-8 -*-
from bottle import route, template, request, response, url, redirect
import os
import uuid, OpenSSL
import time
import hashlib # for password encription with md5

from text_p import *

""" Sign up, log in and log out """

@route('/sign up')
def sign_up():
    """
    Shows a form which allows the user to input its personal data in order to create an account.
    This form is sent via POST to /create account.
    """   
    return template("sign_up", not_comp="", email='', url=url)


@route('/create account', method="POST")
def update_accounts():
    """
    Receives surname, name, email and password from a form, and adds them
    in a text file
    """
    
    m = hashlib.md5() # encript (cryptographic hash function)
    # one way function easy --> hard <--

    sname = request.forms.sname
    name = request.forms.name
    email = request.forms.email
    password = request.forms.password
    password2 = request.forms.password2
    m.update(request.forms.password) 
    pass_enc = m.hexdigest()
    
    not_comp = f_validation(sname, name, email, password, password2)
    
    if (len(not_comp)):
        return  template("sign_up", not_comp=not_comp, email='', url=url)
        
    else:   
        new_a = sname + ' ' + name + ' ' + email + ' ' + pass_enc + ' ' + '\n'
       
        mode = 'a' # add to the text not rewrite
        path = os.path.abspath('date/accounts.txt')
        path = path.replace("\\", "/")
        fob = open(path, mode)
        fob.write(new_a)
        fob.close()
        text_af = "Ett konto har skapats </br> Ange din mail adress: "
        text_af = text_af + email
        return template("account_created", username = text_af, email='', url=url)




@route('/login')
def login():
    return template("login.tpl", matching="", email='', url=url)


@route('/sign', method="POST")
def sign():
    """
    Sign in
    """
    email = request.forms.email
    m = hashlib.md5() # encript (cryptographic hash function)
    m.update(request.forms.password) 
    pass_enc = m.hexdigest()
    
    mode = 'r+' # Opens a file for both reading and writing.
    #The file pointer placed at the beginning of the file.
    path = os.path.abspath('date/accounts.txt')
    path = path.replace("\\", "/")
    searchfile = open(path, mode)
   
    g_p = "" # the password in the database
    email_f = False # email in database
    
    searchfile.seek(0)
    
    for line in searchfile:
        if email in line:
            li = line.split()
            g_p = li[3] # password
            email_f = True
            if g_p == pass_enc:
                
                # start session
                sid = uuid.UUID(bytes = OpenSSL.rand.bytes(16))
                # the cookie persists when the browser is closed
                response.set_cookie("account", sid, secret='some-secret-key', expires=(int(time.time()) + 3600))
                
                write_s(email, sid)
                #link = "<a href='/discutii'>Discutii</a>"
                #return template("template", base="</br><p align='center'>Signed in</p>" + link, email = email, url=url) 
                #return template("discussions", email = email, list_sf = files, detalii = text, url=url)
                redirect('/conversations')
            else:
                searchfile.close()
                return template("login.tpl", matching="</br><p align='center'>Lösenord är ogiltigt</p>", email='', url=url)
    if not(email_f):
        searchfile.close()
        return template("login.tpl", matching="</br><p align='center'>Ange en annan E-postadress.</p>", email = '', url=url)




@route('/logout')
def logout():
    """ Delete the sid from the session db and the cookie """
    
    sid = request.get_cookie("account", secret='some-secret-key')    
    delete_session(str(sid))   
    response.delete_cookie("account") # deletes the cookie
    
    return template("start.tpl", email='', message = "<p><b>Utloggad</b></p><br/>", url=url)














