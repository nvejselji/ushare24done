# -*- coding: utf-8 -*-

from bottle import route, template, request, response, get, post, url
import uuid, OpenSSL
import hashlib
import os
import time
from text_p import *

@route('/admin')
def admin_log():
    sid = request.get_cookie("account", secret='some-secret-key')
    email = get_email(str(sid))
    
    if email:
        return template("start.tpl", email=email, message='Logga ut först!', url=url)
    else:
        return template("admin_li.tpl", message="", url=url)


@route('/signed_admin', method="POST")
def sign():
    """
    Sign in as administrator
    """
    
    admin = request.forms.admin
    m = hashlib.md5() # encript (cryptographic hash function)
    m.update(request.forms.password) 
    pass_enc = m.hexdigest()
    
    mode = 'r+'
    path = os.path.abspath('date/accounts.txt')
    path = path.replace("\\", "/")
    searchfile = open(path, mode)
    first_line = searchfile.readline()
    searchfile.close()
    li = first_line.split()    
    
    if admin == li[0] and pass_enc == li[1]:
        sid = uuid.UUID(bytes = OpenSSL.rand.bytes(16))
        response.set_cookie("account", sid, secret='some-secret-key', expires=(int(time.time()) + 3600))
        write_s(admin, sid)
        
        return template("start.tpl", email=admin, message='', url=url)
        
    else:
        return template("admin_li.tpl", message = "Ange andra uppgifter. Inloggningen misslyckades!", url=url)
    




